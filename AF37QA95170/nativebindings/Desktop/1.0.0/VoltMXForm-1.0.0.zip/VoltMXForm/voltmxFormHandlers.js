const { ipcMain } = require('electron');
const formBootstrap = require('./voltmxFormApiBootstrap');
const { newResult } = require('./utils');

let win; 

function volmxFormHandlers(context) {
    win = context.win;

    ipcMain.on(formBootstrap.channel_form_bootstrap,  (event, args) => {
        event.returnValue = formBootstrap;
    })

    ipcMain.removeHandler(formBootstrap.channel_form_enableMaximizable);
    ipcMain.handle(formBootstrap.channel_form_enableMaximizable,  (event, enable) => {
        console.debug(`handle ${formBootstrap.channel_form_enableMaximizable}: ${enable}`);
        const result = newResult();
        try {
            win?.setMaximizable(enable);
            result.value = true;
        } catch (err) {
            result.error = err;
        }
        return result;
    })

    ipcMain.removeHandler(formBootstrap.channel_form_enableMinimizable);
    ipcMain.handle(formBootstrap.channel_form_enableMinimizable,  (event, enable) => {
        console.debug(`handle ${formBootstrap.channel_form_enableMinimizable}: ${enable}`);
        const result = newResult();
        try {
            win?.setMinimizable(enable);
            result.value = true;
        } catch (err) {
            result.error = err;
        }
        return result;
    })

    ipcMain.removeHandler(formBootstrap.channel_form_enableRestorable);
    ipcMain.handle(formBootstrap.channel_form_enableRestorable,  (event, enable) => {
        console.debug(`handle ${formBootstrap.channel_form_enableRestorable}: ${enable}`);
        const result = newResult();
        try {
            win?.setRestorable(enable);
            result.value = true;
        } catch (err) {
            result.error = err;
        }
        return result;
    })
        
    ipcMain.removeHandler(formBootstrap.channel_form_enableClosable);
    ipcMain.handle(formBootstrap.channel_form_enableClosable,  (event, enable) => {
        console.debug(`handle ${formBootstrap.channel_form_enableClosable}: ${enable}`);
        const result = newResult();
        try {
            win?.setClosable(enable);
            result.value = true;
        } catch (err) {
            result.error = err;
        }
        return result;
    })

    ipcMain.removeHandler(formBootstrap.channel_form_setTitle);
    ipcMain.handle(formBootstrap.channel_form_setTitle,  (event, aTitle) => {
        console.debug(`handle ${formBootstrap.channel_form_setTitle}: ${aTitle}`);
        const result = newResult();
        try {
            win?.setTitle(aTitle);
            result.value = true;
        } catch (err) {
            result.error = err;
        }
        return result;
    })

    win.on('page-title-updated', (evt, newTitle, explicitSet) => {
      console.debug('page-title-updated');
      if (!explicitSet) {
        // Disable setting calculated titles e.g. setting title to ' ' would result in the title being calculated as 'index.html'
        evt.preventDefault();
      }
    });

    win.on('minimize', (evt) => {
      console.log('minimize event triggered');
      evt.sender.send(formBootstrap.channel_form_minimized);
    });
    win.on('maximize', (evt) => {
      console.log('maximize event triggered');
      evt.sender.send(formBootstrap.channel_form_maximized);
    });
    win.on('enter-full-screen', (evt) => {
      console.log('maximize event triggered');
      evt.sender.send(formBootstrap.channel_form_maximized);
    });
    win.on('leave-full-screen', (evt) => {
      console.log('restore event triggered');
      evt.sender.send(formBootstrap.channel_form_restored);
    });
    win.on('restore', (evt) => {
      console.log('restore event triggered');
      evt.sender.send(formBootstrap.channel_form_restored);
    });
    win.on('resize', (evt) => {
      console.log('resize event triggered');
      evt.sender.send(formBootstrap.channel_form_resized);
    });

}

function loadAPIHandlers(context)  {
    this.volmxFormHandlers(context);
}
module.exports = {volmxFormHandlers, loadAPIHandlers};


