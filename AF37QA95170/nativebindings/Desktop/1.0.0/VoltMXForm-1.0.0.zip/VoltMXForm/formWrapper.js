// Replace the voltmx namespace.
// This file cannot reference Node or other modules

if (window.voltmxform?.form) {
    if (window.voltmx) {
        const fireFormEventCallback = function(evt) {
            if (window?.voltmx) {
                const cForm = window.voltmx.application.getCurrentForm();
                window.voltmx.$kwebfw$.widget.fire(cForm, evt, cForm);
            }
        }


        // Add the listener to the renderer process for the form from the main process.
        window.voltmxform.form.setEventCallback(fireFormEventCallback);
        window.voltmxform.form.addFormMaximizedListener();
        window.voltmxform.form.addFormMinimizedListener();
        window.voltmxform.form.addFormRestoredListener();
        window.voltmxform.form.addFormResizedListener();

        if (!Object.getOwnPropertyDescriptor(window.voltmx, 'form')) {
            Object.defineProperty(window.voltmx, 'form', {configurable: true, enumerable: true, writable: true, value: {}});
        }
        window.voltmx.form.enableMaximizable = window.voltmxform.form.enableMaximizable;
        window.voltmx.form.enableMinimizable = window.voltmxform.form.enableMinimizable;
        window.voltmx.form.enableRestorable = window.voltmxform.form.enableRestorable;
        window.voltmx.form.enableClosable = window.voltmxform.form.enableClosable;

        window.voltmx.form.setTitle = window.voltmxform.form.setTitle;
    } else {
        console.log("Could not load formWrapper because window.voltmx does not exist.");
    }
} else {
    console.log("Could not load formWrapper because voltmxform.form does not exist.  Check for preload.js errors.");
}