const IPCEvents = require('./ipcEvents');

module.exports = {
    IPCEvents
}