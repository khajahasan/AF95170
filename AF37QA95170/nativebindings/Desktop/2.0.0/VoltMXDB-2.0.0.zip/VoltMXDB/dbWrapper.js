
if (window.voltmxdb?.db) {
    if (window.voltmx) {
        if (!Object.getOwnPropertyDescriptor(window.voltmx, 'db')) {
            Object.defineProperty(window.voltmx, 'db', {configurable: true, enumerable: true, writable: true, value: {}});
        }
        window.voltmx.db.changeVersion = window.voltmxdb.db.changeVersion;
        window.voltmx.db.executeSql = window.voltmxdb.db.executeSql;
        window.voltmx.db.openDatabase = window.voltmxdb.db.openDatabase;
        window.voltmx.db.closeDatabase = window.voltmxdb.db.closeDatabase;
        window.voltmx.db.readTransaction = window.voltmxdb.db.readTransaction;
        window.voltmx.db.sqlResultsetRowItem = window.voltmxdb.db.sqlResultsetRowItem;
        window.voltmx.db.transaction = window.voltmxdb.db.transaction;
    } else {
        console.log("window.voltmx does not exist.  Could not add dbWrapper");
    }

    // Add the dbTransactionListener defined in preload.js to listener for transaction callbacks

    // function dbTransactionCallback(evt, rendererTransactionId, transactionState, dbObject) {
    //     // return new Promise(async (resolve, reject) => {
    //         // Get the transaction object.
    //         console.log("Executing dbTransactionCallback");
    //         let transContinue = true;
    //         if (dbObject) {
    //             if (transactionState === 'transaction_callback' && dbObject.transactionCallback) {
    //                 dbObject.transactionCallback(rendererTransactionId);
    //             } else if (transactionState === 'transaction_error' && dbObject.transactionErrorCallback) {
    //                 transContinue = dbObject.transactionErrorCallback(rendererTransactionId);
    //                 console.log(`Continue transaction: ${transContinue}`);
    //             }
    //         } else {
    //             throw new Error("Could not find transaction for transaction callback");
    //         }
    //         return transContinue;
    //         // resolve();
    //     // });
    // }
// window.voltmxdb.db.addDbTransactionListener(dbTransactionCallback);
} else {
    console.log("Could not load dbWrapper because voltmxdb.db does not exist.  Check for preload.js errors.")
}
