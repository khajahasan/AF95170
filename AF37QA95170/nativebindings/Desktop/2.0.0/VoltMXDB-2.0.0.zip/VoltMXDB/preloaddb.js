// preloaddb.js

const { contextBridge, ipcRenderer } = require("electron");
console.log("Loading preloaddb.js");

const dbBootstrap = ipcRenderer.sendSync("com.hcl.voltmx.dbBootstrap");
function handleError(error, channel) { 
  if (error) {
    const msg = error.errorMessage ?? error.message;
    throw new Error(msg ? msg : `An error occurred in channel ${channel ? channel : 'unknown'}`);
  }
}

const dbObjects = new Map();
const txnObjectMap = new Map();
let transDispatcher = new TransactionDispatcher();

function newTransactionId() {
  return Date.now().toString(36) + Math.floor(Math.pow(10, 12) + Math.random() * 9*Math.pow(10, 12)).toString(36);
}

function DbObjectWrapper(dbName) {
    this.dbName = dbName;
    this.getDatabase = function(readOnly) { 
      // if(dbpath === undefined) {
      //   dbpath = KonyFileSystem.getDatabaseDirPath();
      // }
      const channel = dbBootstrap.channel_db_openDatabase;
      const results = ipcRenderer.sendSync(channel, this.dbName);
      handleError(results?.error, 'getDatabase');
      return results.value;
	  }

    this.closeDatabase = function(dbId) {
      // const channel = dbBootstrap.channel_db_closeDatabase;
      // const results = ipcRenderer.sendSync(channel, dbId);
      // handleError(results?.error, channel);
    }
	
    this.beginTransaction = function(sqldb) {
      const channel = dbBootstrap.channel_db_begin_transaction;
      const transResults = ipcRenderer.sendSync(channel, sqldb);
      handleError(transResults?.error, channel);
    }

    this.commitTransaction = function(sqldb) {
      const commitChannel = dbBootstrap.channel_db_commit_transaction;
      const commitResults = ipcRenderer.sendSync(commitChannel, sqldb);
      handleError(commitResults?.error, commitChannel);
    }

    this.rollbackTransaction = function(sqldb) {
      const rollbackChannel = dbBootstrap.channel_db_rollback_transaction;
      const rollbackResults = ipcRenderer.sendSync(rollbackChannel, sqldb);
      handleError(rollbackResults?.error, rollbackChannel);
    }

    this.executeSQL = function(sqldb, sqlStatement, args) {
        const channel = dbBootstrap.channel_db_executeSql;
        const results = ipcRenderer.sendSync(channel, sqldb, sqlStatement, args);
        handleError(results.error, channel);
        return results.value;
    }

	  this.transaction = function(params, readOnly) {
		  let errorCallback;
		  let voidCallback;
			if(params.length > 2 && typeof(params[2]) === 'function') {
				errorCallback = params[2];      
      } 
			if(params.length > 3 && typeof(params[3]) === 'function') {
				voidCallback = params[3];
      }
      const transId = newTransactionId();
		  const tran = new Transaction(this, params[1], errorCallback, voidCallback, readOnly, transId);
		  txnObjectMap.set(transId, tran);

			transDispatcher.addTransaction(tran);
      setTimeout(() => {
        transDispatcher.run();
      });
	}
}

function getDbObjectFromId(id) {
    return dbObjects.get(id);
}

function getDbObjectIdWithName(dbName) {
    for (let [key, value] of dbObjects.entries()) {
        if (value.dbName === dbName) {
            return key;
        }
    }
    return undefined;
}

function getDbObjectId(db) {
    for (let [key, value] of dbObjects.entries()) {
        if (value === db) {
            return key;
        }
    }
    return undefined;
}

function setDbObject(id, db) {
    dbObjects.set(id, db);
}

function removeDbObject(id) {
    if (id !== undefined) {
        dbObjects.delete(id);
    }
}

function Transaction(database, transactionCallback, 
      transactionErrorCallback, voidCallback, readOnly, transId) {

  const WEBSQL_TRANSACTION_STATUS_FAIL = 0;
  const WEBSQL_TRANSACTION_STATUS_SUCCESS = 1; 

  this.sqldb = undefined;
  this.errorMsg = undefined;
  this.executeSQLStatements = [];
  this.transactionStatus = WEBSQL_TRANSACTION_STATUS_SUCCESS;
  this.isStale = false; 
  this.database = database;
  this.transactionCallback = transactionCallback;
  this.transactionErrorCallback = transactionErrorCallback;
  this.transactionSuccessCallback = voidCallback;
  this.readOnly = readOnly;
  this.transId = transId;
  
  this.executeErrorCallback = function(callback, code, message){
    if (callback){
      const sqlError = new Error(message);
      sqlError.code = code;
      this.errorMsg = message;
      try {
        const ret = callback(this.transId, sqlError);
        if(ret !== undefined)
          return ret;
      } catch (err) {
        console.log(err);
      }
    }
    return false;
  }

  this.queueExecuteSQL = function(params) {
    if (this.isStale) {
      console.debug("queueExecuteSQL: Tried Queing ExecuteSQL on a completed Transaction throwing INVALID_STATE_ERR");
      throw new Error("INVALID_STATE_ERR");				 
    }

    if (this.transactionStatus !== WEBSQL_TRANSACTION_STATUS_FAIL) {
      this.executeSQLStatements.push(params);
    }
  }

  this.executeSQL = function(params) {
    if (this.isStale) {
      console.log("queueExecuteSQL: Tried ExecuteSQL on a completed Transaction throwing INVALID_STATE_ERR");
      throw new Error("INVALID_STATE_ERR"); 
    }
    if (this.transactionStatus !== WEBSQL_TRANSACTION_STATUS_FAIL){
      //Read Only transactions should allow only "SELECT"
      try {
        
        const qry = params[1];
        // const stmt = compiledStatments.get(qry);
        // if (stmt === undefined){
        // 	stmt = sqldb.compileStatement(qry);
        // 	compiledStatments.put(qry, stmt);
        // }
        const args = params[2];
          
        console.log("SQL Query compiled successfully = " + qry);
        const resultSet = this.database.executeSQL(this.sqldb, qry, args);
        if(params.length > 3 && params[3] !== undefined && typeof(params[3]) === 'function') {
          /* raise success callback */
          try{
            params[3](this.transId,resultSet);
          } catch (err) {
            console.log(err);
          }
        }
      } catch (err) {
        
        /* http://www.w3.org/TR/webdatabase/#dom-sqltransaction-executesql
        1. If the statement had an associated error callback that is not null, 
        then queue a task to invoke that error callback with the SQLTransaction object 
        and a newly constructed SQLError object that represents the error that caused these 
        substeps to be run as the two arguments, respectively, and wait for the task to be run.

        2. If the error callback returns false, then move on to the next statement, if any, 
        or onto the next overall step otherwise.

        3. Otherwise, the error callback did not return false, or there was no error callback. 
        Jump to the last step in the overall steps.
        */
        if (params.length > 4 && typeof(params[4]) === 'function') {
          
          if (!this.executeErrorCallback(params[4], "DATABASE_ERR", err)) {
            this.transactionStatus = WEBSQL_TRANSACTION_STATUS_SUCCESS;
          }
          else {
            this.transactionStatus = WEBSQL_TRANSACTION_STATUS_FAIL;
          }
        }
        else {
          this.transactionStatus = WEBSQL_TRANSACTION_STATUS_FAIL;
        }
        if (this.transactionStatus === WEBSQL_TRANSACTION_STATUS_FAIL) {
          this.executeSQLStatements = [];
        }
      }
    }
    return undefined;
  }
  
  this.execute = function() {
    let callback_invoked = false;
    let isactive = true;
    try {
      this.sqldb = database.getDatabase(readOnly);
      if(!readOnly) {
        this.database.beginTransaction(this.sqldb);
      }

      transactionCallback(this.transId);
      while ((this.executeSQLStatements !== undefined) && (this.executeSQLStatements.length > 0)) {
        this.executeSQL(this.executeSQLStatements.shift());
      }
      // compiledStatments = null;
      //isStale flag indicates transaction is completed and can no longer accept any more execute queries
      this.isStale = true;
        
      console.log("Transaction completed and Marked as stale");
      if (this.transactionStatus !== WEBSQL_TRANSACTION_STATUS_FAIL) {
        if (!readOnly) {
          this.database.commitTransaction(this.sqldb);
          isactive = false;
        }
        if(this.transactionSuccessCallback !== undefined) {
          callback_invoked = true;
          this.transactionSuccessCallback();
        }
      } else if (this.transactionErrorCallback !== undefined) {
        callback_invoked = true;
        const sqlError = new Error(this.errorMsg);
        sqlError.code = "DATABASE_ERR";
        this.transactionErrorCallback(this.transId,sqlError);
      }   
    } catch(err) {
      console.log("Transaction.run error = " + err);
      try {
        if ((callback_invoked === false) && (this.transactionErrorCallback !== null)) {
          callback_invoked = true;
          this.isStale = true;
          try{
            this.transactionErrorCallback(this.transId, err);
          } catch(ex) {						 
              console.log("transactionErrorCallback Exception = " + ex);
              throw ex;
          }
        } else if (this.isStale === true) {
          throw err;
        }
      } finally {
        this.database.rollbackTransaction(this.sqldb);
        isactive = false;
      }
    }	
    finally {
      try {
        if (!this.readOnly && isactive){
          try{
            /*If begin transaction failed,calling endTransaction() will result in 
            exception saying "no transaction pending".This is identified 
            when a plain DB is opened and transacted with password based SQLCipher*/
            if (this.transactionStatus === WEBSQL_TRANSACTION_STATUS_SUCCESS) {
              this.database.commitTransaction(this.sqldb);
            } else {
              this.database.rollbackTransaction(this.sqldb);
            }
          } catch(err)	{
            console.log(err);
          }
        }
        /*There can be unfinished statements so closing database may result in throwing below exception
        "SQLiteException" - unable to close due to unfinalised statements when closing a database
        */
        this.database.closeDatabase(this.sqldb);
      } catch(err) {
        console.log(err);
      }
      this.sqldb = null;
      txnObjectMap.delete(this.transId);
    }
  }
}

function TransactionDispatcher() {
  this.transactions = [];
  
  this.addTransaction = function(tran) {
    this.transactions.push(tran);
  }
  
  this.remove = function() {
    return this.transactions.shift();
  }
    
  this.run = function run() {
    let txn = this.remove();
    while(txn !== undefined) {
      setTimeout(function (aTxn) {aTxn.execute()}, 0, txn);
      txn = this.remove();
    }
  }
}

contextBridge.exposeInMainWorld("voltmxdb", {
        db: {
          // addDbTransactionListener: function(callback) {
          //   ipcRenderer.on("dbTransactionCallback", (evt, rendererTransactionId, transactionState) =>{
          //       const dbObject = getRendererDbObjectFromId(rendererTransactionId);
          //       callback(evt, rendererTransactionId, transactionState, dbObject);
          //   });
          // },
          changeVersion: function(dbaseObjectId, oldVersion, newVersion, transactionCallback, errorCallback, successCallback) {
              // PRAGMA user_version;
              // PRAGMA user_version = newVersion
              console.debug("In changeVersion");

              if (dbaseObjectId !== undefined && oldVersion !== undefined && newVersion !== undefined) {
                // Get version
                const dbObject = getDbObjectFromId(dbaseObjectId);
                if (dbObject) {
                  let sqlStatement = `PRAGMA user_version`;
                  let dbVersion;
                  try {
                    const version = dbObject.executeSQL(dbaseObjectId, sqlStatement, []);
                    if (version) {
                      dbVersion = "" + version[0].user_version;
                    }

                  } catch (err) {
                    if (typeof(errorCallback) === 'function') {
                      errorCallback(dbaseObjectId, err);
                    }
                    return;
                  }
                  if (dbVersion !== undefined && dbVersion === oldVersion) {
                      const updateVersionTransCallback = function(transId) {
                        //Call processSql to update the version
                        const sqlStatement = `PRAGMA user_version=${newVersion}`;
                        dbObject.executeSQL(dbaseObjectId, sqlStatement, []);
                        transactionCallback(transId);
                      }
                      try {
                  			dbObject.transaction([dbaseObjectId, updateVersionTransCallback, errorCallback, successCallback], false);
                      } catch (transErr) {
                        if (typeof(errorCallback) === 'function') {
                          errorCallback(dbaseObjectId, transErr);
                        }
                      }
                  } else {
                    // Old version does not match
                    const changeError = new Error(`Could not change db version since the old version specified ${oldVersion} does not match the current db version ${dbVersion}.`);
                    if (errorCallback && typeof(errorCallback) === 'function') {
                      errorCallback(dbaseObjectId, changeError);
                    } else {
                      throw changeError;
                    }
                  }
                } else {
                    errorCallback(dbaseObjectId, new Error("Database does not exist."));
                }
              } else {
                	throw new Error("Invalid arguments for voltmx.db.changeVersion()");
              }
            },
          executeSql: function(transactionId, sqlStatement, args, successCallback, errorCallback) {
            console.debug("In executeSql");
            try {
              if (transactionId !== undefined && sqlStatement !== undefined) {
                const txnObj  = txnObjectMap.get(transactionId);
                if(txnObj){
                  txnObj.queueExecuteSQL(arguments);
                }
              } else {
                  throw new Error("Invalid arguments for voltmx.db.executeSql().  The transactionId and sqlStatement are required.")
              }
            } finally {
              	console.debug(" EXIT voltmx.db.executeSql " );
            }
          },
          openDatabase: function(dbName, version, displayName, estimatedSize) {
              console.debug("In openDatabase");
              if (dbName !== undefined && version !== undefined && displayName !== undefined) {
                let dbId = getDbObjectIdWithName(dbName);
                if (!dbId) {
                  const channel = dbBootstrap.channel_db_openDatabase;
                  const results = ipcRenderer.sendSync(channel, dbName, version, displayName, estimatedSize);
                  handleError(results?.error, channel);
                  if (results.value) {
                    dbId = results.value;
                    let dbObj = getDbObjectFromId(dbId);
                    if (!dbObj) {
                      dbObj = new DbObjectWrapper(dbName);
                      setDbObject(dbId, dbObj);
                    }
                  }
                }
                return dbId;
              } else {
                throw new Error("Invalid arguments for voltmx.db.openDatabase().  Database name, version and display name must be included.")
              }
            },
          sqlResultsetRowItem: function(transactionId, sqlResultSet, index) {
              console.debug("In sqlResultsetRowItem");
              if (transactionId !== undefined && sqlResultSet !== undefined && index !== undefined) {
                let row = null;
                if (sqlResultSet && Array.isArray(sqlResultSet)) {
                  row = sqlResultSet[index];
                }
                return row;
              } else {
                throw new Error("Invalid arguments for voltmx.db.sqlResultsetRowItem().")
              }
            },
          readTransaction: async function(dbaseObjectId, transactionCallback, transactionErrorCallback, successCallback) {
              console.debug("In readTransaction");
              if (dbaseObjectId !== undefined && transactionCallback !== undefined && typeof( transactionCallback === 'function')) {
                return new Promise((resolve) => {
                  setTimeout(() => {
                    try {
                      const dbObject = getDbObjectFromId(dbaseObjectId);
                			dbObject.transaction(arguments, true);
                    } finally {
                      resolve();
                    }
                  });
                });
              } else {
                throw new Error("Invalid arguments for voltmx.db.readTransaction().")
              }
            },
          transaction: async function(dbaseObjectId, transactionCallback, transactionErrorCallback, successCallback) {
              console.debug("In transaction");
              if (dbaseObjectId !== undefined && transactionCallback !== undefined && typeof( transactionCallback === 'function')) {
                return new Promise((resolve) => {
                  setTimeout(() => {
                    try {
                      const dbObject = getDbObjectFromId(dbaseObjectId);
                			dbObject.transaction(arguments, false);
                    } finally {
                      resolve();
                    }
                  })
                })
              } else {
                throw new Error("Invalid arguments for voltmx.db.transaction().")
              }

            }
          }
  });