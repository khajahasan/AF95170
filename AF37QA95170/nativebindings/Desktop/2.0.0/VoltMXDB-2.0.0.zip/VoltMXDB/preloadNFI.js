const { contextBridge, ipcRenderer } = require('electron');

const IPCEvents = ipcRenderer.sendSync('ipc-events');

class Nfi {
    static initializeDatabase(databaseName, encryptionKey) {
        if (encryptionKey)
            return ipcRenderer.sendSync(IPCEvents.OPEN_DATABASE_WITH_ENCRYPTION, databaseName, encryptionKey);
        else
            return ipcRenderer.sendSync(IPCEvents.OPEN_DATABASE, databaseName);
    }

    /**
     * Executes a raw SQL query
     *
     * @param rawQuery           valid SQL query to execute
     */
    static executeSelectQuery(rawQuery) {
        return ipcRenderer.sendSync(IPCEvents.EXECUTE_SELECT_QUERY, rawQuery);
    }

    /**
     * Executes SQL query as a prepared statement
     *
     * @param sqlQuery
     * @param selectionArgs
     *
     * @return a list of values
     */
    static executeSelectPreparedStatement(sqlQuery, selectionArgs) {
        return ipcRenderer.sendSync(
            IPCEvents.EXECUTE_SELECT_PREPARED_STATEMENTS,
            sqlQuery,
            selectionArgs
        );
    }
    
    /**
     * Executes a valid update SQL statement
     *
     * @param rawQuery valid SQL query to execute. Multiple statements separated by semicolons are not supported.
     */
    static executeQuery(rawQuery) {
        return Nfi.executeQueries([rawQuery], Nfi.DEFAULT_BATCH_SIZE);
    }

    /**
     * Executes a raw SQL query
     * @param rawQuery           valid SQL query to execute
     * @param selectionArgs      a list of values to bind to the query
     * @return {Array}           a list of values
     * @throws {Error}            if the raw query is null or empty
     * 
     * @example
     * 
     * const rawQuery = 'SELECT * FROM table WHERE column = ?';
     * const selectionArgs = ['value'];
     * 
     * const result = Nfi.executeRawQuery(rawQuery, selectionArgs);
     * 
     * console.log(result);
     * 
     * // Output: [{ column: 'value' }]
     */
    static executeRawQuery(rawQuery, selectionArgs) {
        return ipcRenderer.sendSync(IPCEvents.EXECUTE_RAW_QUERY, rawQuery, selectionArgs);
    }

        /**
     * Executes a list of valid update SQL statements.
     *
     * @param rawQueries        a list of valid SQL queries to execute.
     * @param rollbackOnError    If set to true, entire transaction is rolled back,
     *                           else result of successful queries are persisted to DB
     *                           and failed queries of the current transaction are ignored.
     */
    static executeQueries(rawQueries, rollbackOnError) {
        return ipcRenderer.sendSync(IPCEvents.EXECUTE_QUERIES, rawQueries, rollbackOnError);
    }

    /**
     * Executes SQL query as a prepared statement.
     *
     * @param sqlQuery SQL query
     * @param values needed for constructing a prepared statement
     */    
    static executePreparedStatement(sqlQuery, values, rollbackOnError) {
        return ipcRenderer.sendSync(IPCEvents.EXECUTE_PREPARED_STATEMENT, sqlQuery, values, rollbackOnError);
    }

    /**
     * Executes a single INSERT SQL statement and returns the ROW ID of last inserted record in transaction mode
     *
     * @param sqlQuery
     * @param selectionArgs
     *
     * @return rowId of the last inserted record
     */    
    static executeSingleInsertStatement(sqlQuery, selectionArgs){
        return ipcRenderer.sendSync(IPCEvents.EXECUTE_SINGLE_INSERT_STATEMENT, sqlQuery, selectionArgs);
    }

    /**
     * Executes a list of SQL queries as a prepared statements.
     *
     * @param preparedStatements a list of SQL queries and values needed for constructing a
     *                            prepared statements.
     * @param rollbackOnError     If set to true, entire transaction is rolled back,
     *                            else result of successful queries are persisted to DB
     *                            and failed queries of the current transaction are ignored.
     */
    static executePreparedStatements(preparedStatements, rollbackOnError) {
        return ipcRenderer.sendSync(IPCEvents.EXECUTE_PREPARED_STATEMENTS, preparedStatements, rollbackOnError);
    }

    /**
     * Executes a valid update SQL prepared statements with values in transaction mode i.e either
     * ALL or NONE
     *
     * @param preparedStatements a list of SQL queries and values needed for constructing a
     *                            prepared statements.
     */
    static executePreparedStatementsAsTransaction(preparedStatements) {
        return ipcRenderer.sendSync(IPCEvents.EXECUTE_PREPARED_STATEMENTS, preparedStatements, true);
    }    
}


contextBridge.exposeInMainWorld('voltmx_sql', {
  initializeDatabase: Nfi.initializeDatabase,
  closeConnection: Nfi.closeConnection,
  executeSelectQuery: Nfi.executeSelectQuery,
  executeSelectPreparedStatement: Nfi.executeSelectPreparedStatement,
  executeQuery: Nfi.executeQuery,
  executeRawQuery: Nfi.executeRawQuery,
  executeQueries: Nfi.executeQueries,
  executePreparedStatement: Nfi.executePreparedStatement,
  executeSingleInsertStatement: Nfi.executeSingleInsertStatement,
  executePreparedStatements: Nfi.executePreparedStatements,
  executePreparedStatementsAsTransaction: Nfi.executePreparedStatementsAsTransaction,
});
