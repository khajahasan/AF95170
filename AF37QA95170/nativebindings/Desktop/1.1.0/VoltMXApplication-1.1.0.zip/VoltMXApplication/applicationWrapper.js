// Replace the voltmx namespace.
// This file cannot reference Node or other modules

if (window.voltmxapplication?.application) {
    if (window.voltmx) {
        if (!Object.getOwnPropertyDescriptor(window.voltmx, 'application')) {
            Object.defineProperty(window.voltmx, 'application', {configurable: true, enumerable: true, writable: true, value: {}});
        }

        window.voltmx.application.getCurrentSettingsMenu = window.voltmxapplication.application.getCurrentSettingsMenu;
        window.voltmx.application.createDesktopAppMenu = window.voltmxapplication.application.createDesktopAppMenu;
        window.voltmx.application.deleteDesktopAppMenu = window.voltmxapplication.application.deleteDesktopAppMenu;
        window.voltmx.application.insertDesktopAppMenuItem = window.voltmxapplication.application.insertDesktopAppMenuItem;
        window.voltmx.application.deleteDesktopAppMenuItem = window.voltmxapplication.application.deleteDesktopAppMenuItem;
        window.voltmx.application.createDesktopTrayItem = window.voltmxapplication.application.createDesktopTrayItem;
        window.voltmx.application.deleteDesktopTrayItem = window.voltmxapplication.application.deleteDesktopTrayItem;
        window.voltmx.application.customAlert = window.voltmxapplication.application.customAlert;
        window.voltmx.application.addContextMenuItems = window.voltmxapplication.application.addContextMenuItems;
        window.voltmx.application.removeContextMenuItems = window.voltmxapplication.application.removeContextMenuItems;
        window.voltmx.application.removeContextMenu = window.voltmxapplication.application.removeContextMenu
        window.voltmxapplication.application.addMenuClickedListener();
    } else {
        console.log("Could not load applicationWrapper because window.voltmx does not exist.")
    }
} else {
    console.log("Could not load applicationWrapper because voltmxapplication.application does not exist.  Check for preload.js errors.")
}