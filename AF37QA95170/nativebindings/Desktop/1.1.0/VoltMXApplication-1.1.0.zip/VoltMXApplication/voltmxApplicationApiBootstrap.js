module.exports = {
    channel_application_bootstrap: "com.hcl.voltmx.applicationBootstrap",

    channel_application_menuClicked: "com.hcl.voltmx.application.menuClicked",
    
    // Application api channels
    channel_application_getAppMenu: "com.hcl.voltmx.application.getAppMenu",
    channel_application_createAppMenu: "com.hcl.voltmx.application.createAppMenu",
    channel_application_insertAppMenuItem: "com.hcl.voltmx.application.insertAppMenuItem",
    channel_application_deleteAppMenuItem: "com.hcl.voltmx.application.deleteAppMenuItem",
    channel_application_createTrayItem: "com.hcl.voltmx.application.createTrayItem",
    channel_application_deleteTrayItem: "com.hcl.voltmx.application.deleteTrayItem",
    channel_application_customAlert: "com.hcl.voltmx.application.customAlert",
    channel_application_addContextMenuItems: "com.hcl.voltmx.application.addContextMenuItems",
    channel_application_removeContextMenuItems: "com.hcl.voltmx.application.removeContextMenuItems",
    channel_application_removeContextMenu: "com.hcl.voltmx.application.removeContextMenu",
}